import React from "react";
import { useFormik } from "formik";
import axios from "axios";
import { useMutation } from "@tanstack/react-query";
import TextBox from "./TextBox";
import Button from "@mui/material/Button";


export const Login = () => {
  const createLogin = useMutation({
    mutationFn: async (data) => {
        const loginResponse =  await axios.post("http://localhost:3001/login", data);
        localStorage.setItem("response", loginResponse.data.auth);
        // console.log(loginResponse.data);
        
    },
    onSuccess:() => {
        alert("login sucess.....");
    },
    onError:() => {
        alert('error....')
    }
  });
  const { handleSubmit, setFieldValue } = useFormik({
    initialValues: { email: "", password: "" },
    onSubmit: async (data) => {
      console.log(data);
      await createLogin.mutateAsync(data)
    },
  });

  return (
    <>
      <div>
        <h1>Login Here</h1>
        <form onSubmit={handleSubmit}>

          <TextBox label="email" type="text" size="small" 
          variant="outlined" onChange={(e) => setFieldValue('email',e.target.value)}/>

          <TextBox label="password" type="password" size="small"
           variant="outlined" onChange={(e) => setFieldValue('password',e.target.value)}/>
          
          <Button variant="contained" type="submit">Submit</Button>
        </form>
      </div>
    </>
  );
};
