import React, { useEffect, useState } from "react";
import axios from "axios";

const UserComponents = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:3001/users")
      .then((response) => {
        setData(response.data.users);
      })
      .catch((e) => console.log(e));
  }, []);

  console.log(data);
  return (
    <>
      <table border={1}>
        <thead>
          <tr>
            <th>NO.</th>
            <th>Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <tr>
                <td>{index + 1}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
};

export default UserComponents;
