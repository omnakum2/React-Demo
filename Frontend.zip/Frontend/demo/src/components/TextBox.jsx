import React from "react";
import TextField from "@mui/material/TextField";

const TextBox = (props) => {
  return (
    <TextField
      label={props.label}
      type={props.type}
      size={props.size}
      variant={props.variant}
      onChange={props.onChange}
    />
  );
};

export default TextBox;
