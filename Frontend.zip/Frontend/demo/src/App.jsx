import React from 'react'
import UserComponents from './components/UserComponents'
import { Login } from './components/Login'
import {QueryClientProvider, QueryClient} from "@tanstack/react-query"

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider  client={queryClient}>
      <Login/>
    </QueryClientProvider>
  )
}

export default App